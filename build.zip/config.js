var env = {
  "CYBER_CHAINGEAR_API": "http://93.125.26.210:32600",
  "CYBER_SEARCH_API": "http://93.125.26.210:32901",
  "CYBER_MARKETS_API": "http://93.125.26.210:32800",
  // "CYBER_MARKETS_API": "https://min-api.cryptocompare.com/data",
  "CYBER_MARKETS_STREAM_API": "ws://93.125.26.210:32801"
}
